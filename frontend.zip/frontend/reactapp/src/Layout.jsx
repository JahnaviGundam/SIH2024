import React from 'react'
import Header from './Components/Header'
import { Outlet } from 'react-router-dom'
import Footer from './Components/Footer'
function Layout() {
  return (
    <div className='flex flex-row'>
      <Header/>
      <div className='flex flex-col'>
      <Outlet/>
      <Footer/>
      </div>
    </div>
  )
}

export default Layout
