import React from 'react'

function LeaderBoard() {
  return (
    <div>
      leaderboard
    </div>
  )
}

export default LeaderBoard
