import React from 'react'

function Card() {
  return (
    <div>
      card
    </div>
  )
}

export default Card
