import React from 'react'

function Snake() {
  return (
    <div>
      snake
    </div>
  )
}

export default Snake
