import React from 'react'

function Spin() {
  return (
    <div>
      spin
    </div>
  )
}

export default Spin
