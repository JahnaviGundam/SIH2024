import React from 'react'

function Footer() {
  return (
    <div>
      footer
    </div>
  )
}

export default Footer
